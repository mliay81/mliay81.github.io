$( document ).ready(function() {
    console.log( "ready!" )


    
    
// User-selected date from HTML datepicker
$("#zipSubmit").on("click", function(event) {
    event.preventDefault()
// This will capture the date
    var date = $("#eventDate").val()
    console.log(date)
// This will convert the date to YYYYMMDD format for API use
    var cleanDate = moment(date).format("YYYYMMDD")
    console.log(cleanDate)
})


var apiKey = "&app_key=Z7xkcSgfKkKgMTxQ";
var baseUrl = "https://api.eventful.com/json/events/search?";
var location = "&l=";
var milesWithin = "&within10&units=miles";
var date = "&date=Today";
var queryUrl = "";
$("#zipSubmit").on("click", function (event) {
  event.preventDefault;
  var zipCode = $("#zip").val().trim();
  console.log(zipCode);
  var zipLocation = location + zipCode;
  queryUrl = baseUrl + zipLocation + milesWithin + date + apiKey;
  console.log(queryUrl);
  $.ajax({
    url: queryUrl,
    method: 'GET'
  }).then(function (response) {
    console.log("Returning response");
    console.log(response);
    var data = JSON.parse(response); //Convert Json text to a javascript's object
    var eventsResult = data.events.event;
    for (i = 0; i < eventsResult.length; i++) {
      appendEvent(eventsResult, i)
    }
  })
  function appendEvent(eventsResult, i) {
    var title = verifyNullOrUndefined(eventsResult[i].title);
    var startTime = verifyNullOrUndefined(eventsResult[i].start_time);
    var venueName = verifyNullOrUndefined(eventsResult[i].venue_name);
    var venueAddress = verifyNullOrUndefined(eventsResult[i].venue_address);
    var description = verifyNullOrUndefined(eventsResult[i].description);
    var url = verifyNullOrUndefined(eventsResult[i].url);
    var eventDiv = $("<div>");
    eventDiv.html("<p>" + title + "</p><p>" + startTime + "</p><p>" + venueName + "</p><p>" + venueAddress + "</p><p>" + description + "</p><a href='" + url + "'>" + url + "</a>")
    $("#event-div").append(eventDiv);
  }
  function verifyNullOrUndefined(value) {
    if (value === null || value === undefined) {
      value = "Not available";
    }
    return value;
  }
})




$("#zipSubmit").click(function() {
    event.preventDefault()
    var zip = $("#zip").val()
    console.log(zip)

    var queryURL = "https://api.apixu.com/v1/forecast.json?key=424cbaf05adf4e88b3f12251182606&q=" + zip + "&days=10"
    var URL2 = "https://api.yelp.com/v3/businesses/search.location.zip_code"
    

    $.ajax({
            url: queryURL,
            method: "GET"
        })
        .then(function(response) {
            // console.log(queryURL)
            console.log(response.forecast.forecastday[0].day.condition.text)
            console.log(response.forecast.forecastday[0].day.maxtemp_f)
            var weather = $("<div>").html("Your weather is: " + response.forecast.forecastday[0].day.maxtemp_f + " with " + response.forecast.forecastday[0].day.condition.text)
            $("#weather-div").append(weather)
            // console.log(response.location.name)
            // console.log(response.forecast.forecastday)
        //     var location = response.location.name;
        //     for (var i = 0; i < response.forecast.forecastday.length; i++) 
        //     {
        //     // console.log(i);
        //     // console.log(response.current.condition);
        //     var imgURL = "https://" + response.forecast.forecastday[i].day)
        //     var image = $("<img>").attr("src", imgURL)
        //     $("#temp").html("Temp:" + response.current.temp_f)
        //     $("#city").html("City: " + response.location.name)
        //     $("#weatherResults").html("Forecast:" + response.forecast.forecastday[i].day.condition.text)
        //     $("#picture").append(image)
        //     }
        //     var imgURL = "https://" + response.forecast.forecastday[i].day.condition.icon
        //     var image = $("<img>").attr("src", imgURL)
        // $("#city").html("City: " + response.location.name)
        // $("#weatherResults").html("Forecast: " + response.forecast.forecastday[i].day.text)
        // $("#picture").append(image)

        })

        
})

$("#zipSubmit").click(function() {
    event.preventDefault()
    var zip = $("#zip").val()
    $("#zip").val("")
    console.log(zip)

    var URL2 = "https://maps.googleapis.com/maps/api/place/textsearch/json?query=restaurant+near+" + zip + "&units=miles&radius=5000&key=AIzaSyDGgpT5rI2_KH0Ny97NXtTiPSGXtgnNlac"
    var nextPage = "https://maps.googleapis.com/maps/api/place/textsearch/json?next_page_token=CpQCCAEAAKKS6uJmZGdZ1J_buLGPdp8Kc0UgHu3wLU5dfdbijQ3JPd316pnvpPk5tGir4SRCnjUMyaIqF2TsfcSPvFuJ3xs1-dQl-ZCcQgY3oK2bkRSQMq6DPirvE8IG-mzjso6ItB40f_pyzSdpDszaqPfopNSh5ocfWoRwMCTcg20QrpM9gwXU5LFSQ8H0ry0DCqICFZl7JyXgimtG8BwvrMKUbWqT850a1TX8QR9K5LAxZwhHARCPTQn0DMggcbPbVwbqtUONqdIohLuztQtEIaIT6hHNVMGb_ouevlxNNFv2CGXVXfEIzCRpBCPmfLR8nQXiQQNrSYznEbdB7SH1HmKKkzF189dy1kPG8b7gUydoxSPdEhAMus22L_t5xSmn9MxMBrJCGhRNKYDeZeIQNAnh0itT178TyFUdsQ&key=AIzaSyDGgpT5rI2_KH0Ny97NXtTiPSGXtgnNlac"
    console.log(URL2)
    // Attempt at pulling the "next page of results" from Google, but I couldn't figure that out.
    console.log(nextPage)
    var corsURL = "https://cors-anywhere.herokuapp.com/" + URL2
    console.log(corsURL)

    $.ajax({
        url: URL2,
        method: "GET",
        dataType: "json",
        // this headers section is necessary for CORS-anywhere
        headers: {
          "x-requested-with": "xhr",
        }
      }).done(function(response) {
        console.log('CORS anywhere response', response);

        // This will create a div containing the results from the Google API, then append it to an existing HTML div
        // for (i = 0; i < response.results.length; i++) {
        //     console.log("name: " + response.results[i].name)
        //     var rest = $("<div>").html(response.results[i].name)
        //     $("#weather-div").append(rest)
        // }

        // This will pick a random restaurant choice from the Google API results
        // then append it to an existing HTML div
        var name = response.results[Math.floor(Math.random() * response.results.length)].name
        console.log("random: " + name)
        var random = $("<div>").html("Your random dinner choice is: " + name)
        $("#restaurant-div").append(random)

        // This is part of the CORS code 
        }).fail(function(jqXHR, textStatus) {
            console.error(textStatus)
        })

})

$.backstretch("./assets/images/image2.jpg");
  
  var granimInstance = new Granim({
    element: '#canvas-basic',
    name: 'basic-gradient',
    direction: 'left-right', // 'diagonal', 'top-bottom', 'radial'
    opacity: [1, 1],
    isPausedWhenNotInView: true,
    image: {
      source: './assets/images/image2.jpg',
      blendingMode: 'multiply',
    },
    states: {
      "default-state": {
        gradients: [
          ['#AA076B', '#61045F'],
          ['#02AAB0', '#00CDAC'],
          ['#DA22FF', '#9733EE']
        ]
      }
    }
  });


  





})